import javax.swing.JOptionPane;
public class UsandoOptionPane {
    public static void main(String[] args) {
        
        JOptionPane.showMessageDialog(null, "Teste de Mensagem");
        
        JOptionPane.showMessageDialog(null, "Esse é um aviso importatne", "Minha mensagem", JOptionPane.WARNING_MESSAGE);
    }
}
